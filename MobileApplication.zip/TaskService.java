import java.util.ArrayList;

public class TaskService {
	private ArrayList<Task> tasks = new ArrayList<Task>(); 
	
	public void addTask(String id, String fName, String desc) {
		for (Task task : tasks) {
			if (task.getID() == id) {
				return;
			}
		}
		Task task = new Task(id, fName, desc);
		tasks.add(task);
	}
	
	public Task getTask(String id) {
		for (Task task : tasks) {
			if (task.getID() == id) {
				return task;
			}
		}
		return null;
	}
	
	public Task getLastTask() {
		return tasks.get(tasks.size()-1);
	}
	
	public void deleteTask(String id) {
		for (Task task : tasks) {
			if (task.getID() == id) {
				tasks.remove(task);
			}
		}
	}
	
	public void updateName(String id, String fName) {
		for (Task task : tasks) {
			if (task.getID()== id) {
				task.setName(fName);
			}
		}
	}
	
	public void updateDescription(String id, String fName) {
		for (Task task : tasks) {
			if (task.getID()== id) {
				task.setDescription(fName);
			}
		}
	}
	
}
