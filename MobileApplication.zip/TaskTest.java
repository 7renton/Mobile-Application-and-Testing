import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {
	// ID 
	@Test
	void idCanBeNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(null,"notNull","notNull");
		});
	}
	@Test
	void idCanBeGreaterThanTenDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("MoreThanTen","notNull","notNull");
		});
	}
	//I couldn't figure out how to test for the nonexistence of a method so I made sure it exists in a nonfunctional way
	@Test
	void itIsPossibleToChangeID() {
			Task task = new Task("originalID","notNull","notNull");
			task.setID("changedID");
			if(task.getID() != "originalID") {
				fail();
			}		
	}
	
	//  name
	@Test
	void  nameCanBeNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("notNull", null,"notNull");
		});
	}
	@Test
	void  nameCanBeGreaterThanTwentyDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("notNull","123456789012345678901","notNull");
		});
	}
	
	// description
	@Test
	void descriptionIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("notNull","notNull", null);
		});
	}
	@Test
	void descriptionIsGreaterThanFiftyDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("notNull","notNull","123456789012345678901234567890123456789012345678901");
		});
	}
	
	//// UPDATING MEMBER VARIABLES
		
	@Test
	void canUpdateNameWithNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("notNull", "notNull","notNull");
			task.setName(null);
		});
	}
	@Test
	void canUpdateNameWithMoreThanTenCharacters() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("notNull", "notNull","notNull");
			task.setName("moreThanTen");
		});
	}
	@Test
	void cantGetName() {
		Task task = new Task("notNull", "notNull","notNull");
		if(!task.getName().equals("notNull")) {
			fail();
		}
	}
	@Test
	void cantUpdateNameWithValidArguement() {
		Task task = new Task("notNull", "notNull","notNull");
		task.setName("updated");
		if(!"updated".equals(task.getName())) {
			fail();
		}
	}
	
	@Test
	void canUpdateDescriptionWithNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("notNull", "notNull","notNull");
			task.setDescription(null);
		});
	}
	@Test
	void canUpdateDescriptionWithMoreThanTenCharacters() {
		assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("notNull", "notNull","notNull");
			task.setDescription("OneMoreThanFifty00000000000000000000000000000000000");
		});
	}
	@Test
	void cantGetDescription() {
		Task task = new Task("notNull", "notNull","notNull");
		if(!task.getDescription().equals("notNull")) {
			fail();
		}
	}
	@Test
	void cantUpdateDescriptionWithValidArguement() {
		Task task = new Task("notNull", "notNull","notNull");
		task.setDescription("updated");
		if(!"updated".equals(task.getDescription())) {
			fail();
		}
	}
	

	

}
