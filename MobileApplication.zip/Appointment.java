import java.time.Clock;
import java.util.Date;

public class Appointment {
	String ID;
	Date date;
	String description;
	
	public Appointment(String id, Date dt, String desc) {
		if(id == null || id.length() > 10)
			throw new IllegalArgumentException("Invalid ID");
		else
			ID = id;
		if(dt == null || dt.compareTo(new Date()) < 0 )
			throw new IllegalArgumentException("Before current time");
		else
			date = dt;
		if(desc == null || desc.length() > 50)
			throw new IllegalArgumentException("Invalid description");
		else
			description = desc;
	}
	
	public void setID(String a) {
		//I couldn't figure out how to test for the nonexistence of a method so I made sure it exists in a nonfunctional way
		System.out.print("Can not Change ID");
	}
	public String getID() {
		return ID;
	}
	
	public void setDate(Date dt) {
		if(dt == null ||dt.compareTo(new Date()) < 0 )
			throw new IllegalArgumentException("Before current time");
		else
			date = dt;
	}
	public Date getDate() {
		return date;
	}
	
	public void setDescription(String desc) {
		if(desc == null || desc.length() > 50)
			throw new IllegalArgumentException("Invalid lastName");
		else
			description = desc;
	}
	public String getDescription() {
		return description;
	}
}
