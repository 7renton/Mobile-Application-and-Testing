

public class Contact {
	private String ID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	public Contact(String id, String fName, String lName, String pNum, String addrs) {
		
		if(id == null || id.length() > 10)
			throw new IllegalArgumentException("Invalid ID");
		else
			ID = id;
		//////////////////////
		if(fName == null || fName.length() > 10)
			throw new IllegalArgumentException("Invalid firstName");
		else
			firstName = fName;
		//////////////////////
		if(lName == null || lName.length() > 10)
			throw new IllegalArgumentException("Invalid lastName");
		else
			lastName = lName;
		///////////////////////
		if(pNum == null || pNum.length() != 10)
			throw new IllegalArgumentException("Invalid lastName");
		else
			phoneNumber = pNum;
		////////////////////////
		if(addrs == null || (addrs.length() > 30)) 
			throw new IllegalArgumentException("Invalid firstName");
		else
			address = addrs;
	}
	
	public void setID(String a) {
		//I couldn't figure out how to test for the nonexistence of a method so I made sure it exists in a nonfunctional way
		System.out.print("Can not Change ID");
	}
	public String getID() {
		return ID;
	}
	public void setFirstName(String name) {
		if(name == null || name.length() > 10)
			throw new IllegalArgumentException("Invalid lastName");
		else
			firstName = name;
	}
	public String getFirstName() {
		return firstName;
	}
	
	public void setLastName(String name) {
		if(name == null || name.length() > 10)
			throw new IllegalArgumentException("Invalid lastName");
		else
			lastName = name;
	}
	public String getLastName() {
		return lastName;
	}
	
	public void setPhoneNumber(String num) {
		if(num == null || num.length() != 10)
			throw new IllegalArgumentException("Invalid lastName");
		else
			phoneNumber = num;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setAddress(String adrs) {
		if(adrs == null || adrs.length() > 30)
			throw new IllegalArgumentException("Invalid lastName");
		else
			address = adrs;
	}
	public String getAddress() {
		return address;
	}
}
