import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.fail;

import org.junit.jupiter.api.Test;

class TaskServiceTest {


	@Test
	void WansntAbleToAddTaskWithUniqueID() {
		TaskService tService = new TaskService();
		tService.addTask("UniqueID","notNull","notNull");
		if(tService.getLastTask().getID() != "UniqueID") {
			fail();
		}
		System.out.println(System.nanoTime());
		for(int i= 0; i < 10000; i++) {
			
		}
		System.out.println(System.nanoTime());
	}
	
	@Test
	void WasAbleToAddTaskWithSameID() {
		TaskService tService = new TaskService();
		tService.addTask("1","notNull","notNull");
		tService.addTask("1","ffdffs","fdfsfa");
		if(tService.getLastTask().getName() != "notNull") {
			fail();
		}
	}
	
	@Test
	void WasntAbleToDeleteTaskPerID() {
		TaskService tService = new TaskService();
		tService.addTask("1","notNull","notNull");
		tService.addTask("2","ffdffs","fdfsfa");
		tService.addTask("3","notNull","notNull");
		tService.deleteTask("2");
		if(tService.getTask("2") != null) {
			fail();
		}
	}
	
	@Test
	void NameIsntUpdateAble() {
		TaskService tService = new TaskService();
		tService.addTask("1","notNull","notNull");
		tService.addTask("2","notNull","notNull");
		tService.updateName("2", "Different");
		if(tService.getTask("2").getName() != "Different") {
			fail();
		}
	}
	
	@Test
	void DescriptionIsntUpdateAble() {
		TaskService tService = new TaskService();
		tService.addTask("1","notNull","notNull");
		tService.addTask("2","notNull","notNull");
		tService.updateDescription("2", "Different");
		if(tService.getTask("2").getDescription() != "Different") {
			fail();
		}
	}

}
