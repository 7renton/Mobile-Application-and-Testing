import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestContactService {

	@Test
	void WansntAbleToAddContactWithUniqueID() {
		ContactService cService = new ContactService();
		cService.addContact("UniqueID","notNull","notNull","Exactly_10","notNull");
		if(cService.getLastContact().getID() != "UniqueID") {
			fail();
		}
	}
	
	@Test
	void WasAbleToAddContactWithSameID() {
		ContactService cService = new ContactService();
		cService.addContact("1","notNull","notNull","Exactly_10","notNull");
		cService.addContact("1","ffdffs","fdfsfa","1234567890","fdsfafdf");
		if(cService.getLastContact().getFirstName() != "notNull") {
			fail();
		}
	}
	
	@Test
	void WasntAbleToDeleteContactPerID() {
		ContactService cService = new ContactService();
		cService.addContact("1","notNull","notNull","Exactly_10","notNull");
		cService.addContact("2","ffdffs","fdfsfa","1234567890","fdsfafdf");
		cService.addContact("3","notNull","notNull","Exactly_10","notNull");
		cService.deleteContact("2");
		if(cService.getContact("2") != null) {
			fail();
		}
	}
	
	@Test
	void FirstNameIsntUpdateAble() {
		ContactService cService = new ContactService();
		cService.addContact("1","notNull","notNull","Exactly_10","notNull");
		cService.addContact("2","notNull","notNull","Exactly_10","notNull");
		cService.updateFirstName("2", "Different");
		if(cService.getContact("2").getFirstName() != "Different") {
			fail();
		}
	}
	
	@Test
	void LastNameIsntUpdateAble() {
		ContactService cService = new ContactService();
		cService.addContact("1","notNull","notNull","Exactly_10","notNull");
		cService.addContact("2","notNull","notNull","Exactly_10","notNull");
		cService.updateLastName("2", "Different");
		if(cService.getContact("2").getLastName() != "Different") {
			fail();
		}
	}
	
	@Test
	void NumberIsntUpdateAble() {
		ContactService cService = new ContactService();
		cService.addContact("1","notNull","notNull","Exactly_10","notNull");
		cService.addContact("2","notNull","notNull","Exactly_10","notNull");
		cService.updateNumber("2", "Diferent10");
		if(cService.getContact("2").getPhoneNumber() != "Diferent10") {
			fail();
		}
	}
	
	@Test
	void AddresIsntUpdateAble() {
		ContactService cService = new ContactService();
		cService.addContact("1","notNull","notNull","Exactly_10","notNull");
		cService.addContact("2","notNull","notNull","Exactly_10","notNull");
		cService.updateAddress("2", "Different");
		if(cService.getContact("2").getAddress() != "Different") {
			fail();
		}
	}

}
