public class Task {
	private String ID;
	private String name;
	private String description;
	
	public Task(String id, String n, String desc) {
		if(id == null || id.length() > 10)
			throw new IllegalArgumentException("Invalid ID");
		else
			ID = id;
		if(n == null || n.length() > 20)
			throw new IllegalArgumentException("Invalid name");
		else
			 name = n;
		if(desc == null || desc.length() > 50)
			throw new IllegalArgumentException("Invalid description");
		else
			description = desc;
	}
	
	public void setID(String a) {
		//I couldn't figure out how to test for the nonexistence of a method so I made sure it exists in a nonfunctional way
		System.out.print("Can not Change ID");
	}
	public String getID() {
		return ID;
	}
	
	public void setName(String n) {
		if(n == null || n.length() > 10)
			throw new IllegalArgumentException("Invalid name");
		else
			 name = n;
	}
	public String getName() {
		return  name;
	}
	
	public void setDescription(String desc) {
		if(desc == null || desc.length() > 50)
			throw new IllegalArgumentException("Invalid description");
		else
			description = desc;
	}
	public String getDescription() {
		return description;
	}
	
}

