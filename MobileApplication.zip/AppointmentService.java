import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	private ArrayList<Appointment> appointments = new ArrayList<Appointment>(); 
	
	public void addAppointment(String id, Date dt, String desc) {
		for (Appointment appointment : appointments) {
			if (appointment.getID() == id) {
				throw new IllegalArgumentException("ID already being used");
			}
		}
		Appointment appointment = new Appointment(id, dt, desc);
		appointments.add(appointment);
	}
	
	public Appointment getAppointment(String id) {
		for (Appointment appointment : appointments) {
			if (appointment.getID() == id) {
				return appointment;
			}
		}
		return null;
	}
	
	public void deleteAppointment(String id) {
		for (Appointment appointment : appointments) {
			if (appointment.getID() == id) {
				appointments.remove(appointment);
			}
		}
	}
	
	
}
