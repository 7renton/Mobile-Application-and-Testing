
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.time.Clock;

//import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class testContact {

	// ID 
	@Test
	void idIsNull() {
		System.out.print(Clock.systemUTC().instant());
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(null,"notNull","notNull","Exactly_10","notNull");
		});
	}
	@Test
	void idIsGreaterThanTenDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("MoreThanTen","notNull","notNull","Exactly_10","notNull");
		});
	}
	//I couldn't figure out how to test for the nonexistence of a method so I made sure it exists in a nonfunctional way
	@Test
	void itIsPossibleToChangeID() {
			Contact contact = new Contact("originalID","notNull","notNull","Exactly_10","notNull");
			contact.setID("changedID");
			if(contact.getID() != "originalID") {
				fail();
			}		
	}
	
	// firstName
	@Test
	void firstNameIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", null,"notNull","Exactly_10","notNull");
		});
	}
	@Test
	void firstNameIsGreaterThanTenDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull","MoreThanTen","notNull","Exactly_10","notNull");
		});
	}
	
	// lastName
	@Test
	void lastNameIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull","notNull", null,"Exactly_10","notNull");
		});
	}
	@Test
	void lastNameIsGreaterThanTenDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull","notNull","MoreThanTen","Exactly_10","notNull");
		});
	}
	
	// number
	@Test
	void numberNameIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull","notNull", "notNull", null,"notNull");
		});
	}
	@Test
	void numberDoesntEqualTenDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull","notNull","notNull","moreThanTen","notNull");
		});
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact1 = new Contact("notNull","notNull","notNull","belowTen","notNull");
		});
	}
	
	// address
	@Test
	void addressIsNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull","notNull","notNull","Exactly_10",null);
		});
	}
	@Test
	void addressIsGreaterThanThirtyDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull","notNull","notNull","Exactly_10","moreThanThirtyDigits12345678901");
		});
	}
	
// 	UPDATING MEMBER FUNCTIONS //////////////////////////////////
	@Test
	void canUpdateFirstNameWithNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setFirstName(null);
		});
	}
	@Test
	void canUpdateFirstNameWithMoreThanTenCharacters() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setFirstName("moreThanTen");
		});
	}
	
	@Test
	void cantGetFirstName() {
		Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
		if(!contact.getFirstName().equals("notNull")) {
			fail();
		}
	}
	@Test
	void cantUpdateFirstNameWithValidArguement() {
		Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
		contact.setFirstName("updated");
		if(!"updated".equals(contact.getFirstName())) {
			fail();
		}

	}
	///////////////
	@Test
	void canUpdateLastNameWithNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setLastName(null);
		});
	}
	@Test
	void canUpdateLastNameWithMoreThanTenCharacters() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setLastName("moreThanTen");
		});
	}
	@Test
	void cantGetLastName() {
		Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
		if(!contact.getLastName().equals("notNull")) {
			fail();
		}
	}
	@Test
	void cantUpdateLastNameWithValidArguement() {
		Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
		contact.setLastName("updated");
		if(!"updated".equals(contact.getLastName())) {
			fail();
		}	

	}
	////////////////
	@Test
	void canUpdatePhoneNumberWithNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setPhoneNumber(null);
		});
	}
	@Test
	void canUpdatePhoneNumberWithCharactersGreaterToTen() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setPhoneNumber("moreThanTen");
		});
	}
	@Test
	void canUpdatePhoneNumberWithCharactersLessThanTen() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setPhoneNumber("123456789");
		});
	}
	@Test
	void cantGetPhoneNumber() {
		Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
		if(!contact.getPhoneNumber().equals("Exactly_10")) {
			fail();
		}
	}
	@Test
	void cantUpdatePhoneNumberWithValidArguement() {
		Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
		contact.setPhoneNumber("1234567890");
		if(!"1234567890".equals(contact.getPhoneNumber())) {
			fail();
		}
	}
	///////////////
	@Test
	void canUpdateAddressWithNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setAddress(null);
		});
	}
	@Test
	void canUpdateAddressWithCharactersGreaterToThirty() {
		assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
			contact.setAddress("moreThanThirtyDigits12345678901");
		});
	}
	@Test
	void cantGetAddress() {
		Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
		if(!contact.getAddress().equals("notNull")) {
			fail();
		}
	}
	@Test
	void cantUpdateAddressWithValidArguement() {
		Contact contact = new Contact("notNull", "notNull","notNull","Exactly_10","notNull");
		contact.setAddress("1234567890");
		if(!"1234567890".equals(contact.getAddress())) {
			fail();
		}
	}
	
}
