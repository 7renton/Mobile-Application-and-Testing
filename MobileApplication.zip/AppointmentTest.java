import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

class AppointmentTest {

	@Test
	void possibleToCreateAppointmentWithNullID() {
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment(null, new Date(),"notNull");
		});
	}
	@Test
	void possibleToCreateAppointmentWithIDLargerThanTenDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("moreThanTen", new Date(),"notNull");
		});
	}
	//I couldn't figure out how to test for the nonexistence of a method so I made sure it exists in a nonfunctional way
	@Test
	void possibleToUpdateID() {
			Appointment appointment = new Appointment("originalID",new Date(),"notNull");
			appointment.setID("changedID");
			if(appointment.getID() != "originalID") {
				fail();
			}		
	}
	
	
	@Test
	void possibleToCreateAppointmentWithNullDate() {
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("notNull", null,"notNull");
		});
	}
	@Test
	void possibleToCreateAppointmentWithPastDate() {
		Date previousTime = new Date();
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("notNull", previousTime,"notNull");
		});
	}
	@Test
	void possibleToUpdateAppointmentWithNullDate() {
		Appointment appointment = new Appointment("notNull", new Date(),"notNull");
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setDate(null);
		});
	}
	@Test
	void possibleToUpdateAppointmentWithPastDate() {
		Appointment appointment = new Appointment("notNull", new Date(),"notNull");
		Date previousTime = new Date();
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setDate(previousTime);
		});
		
	}
	@Test
	void notPossibleToUpdateAppointmentWithFutureDate() {
		Date date = new Date(3000+1900,01,01);
		Appointment appointment = new Appointment("notNull", new Date(),"notNull");
		appointment.setDate(date);
		if(appointment.getDate().compareTo(date) != 0) {
			fail();
		}
	}
		
	
	
	@Test
	void possibleToCreateAppointmentWithNulldescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("notNull",new Date(),null);
		});
	}
	@Test
	void possibleToCreateAppointmentWithTooLongDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("notNull",new Date(),"ThisIsFiftyOneCharactersLong00000000000000000000000");
		});
	}
	@Test
	void possibleToUpdateAppointmentWithNullDescription() {
			Appointment appointment = new Appointment("notNull",new Date(),"notNull");
			assertThrows(IllegalArgumentException.class, () -> {
				appointment.setDescription(null);
			});
	}
	@Test
	void possibleToUpdateAppointmentWithTooLongDescription() {
		Appointment appointment = new Appointment("notNull",new Date(),"notNull");
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setDescription("ThisIsFiftyOneCharactersLong00000000000000000000000");
		});
	}
	@Test
	void notPossibleToUpdateAppointmentWithValidDescription() {
		String desc = "fdsaffsafasdfds";
		Appointment appointment = new Appointment("notNull", new Date(),"notNull");
		appointment.setDescription(desc);
		if(appointment.getDescription() != desc) {
			fail();
		}
	}
	
	
}
