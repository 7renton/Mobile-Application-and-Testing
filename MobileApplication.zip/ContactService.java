import java.util.ArrayList;

public class ContactService {
	private ArrayList<Contact> contacts = new ArrayList<Contact>(); 
	
	public void addContact(String id, String fName, String lName, String pNum, String addrs) {
		for (Contact contact : contacts) {
			if (contact.getID() == id) {
				return;
			}
		}
		Contact contact = new Contact(id, fName, lName, pNum, addrs);
		contacts.add(contact);
	}
	
	public Contact getContact(String id) {
		for (Contact contact : contacts) {
			if (contact.getID() == id) {
				return contact;
			}
		}
		return null;
	}
	
	public Contact getLastContact() {
		return contacts.get(contacts.size()-1);
	}
	
	public void deleteContact(String id) {
		for (Contact contact : contacts) {
			if (contact.getID() == id) {
				contacts.remove(contact);
			}
		}
	}
	
	public void updateFirstName(String id, String fName) {
		for (Contact contact : contacts) {
			if (contact.getID()== id) {
				contact.setFirstName(fName);
			}
		}
	}
	
	public void updateLastName(String id, String fName) {
		for (Contact contact : contacts) {
			if (contact.getID()== id) {
				contact.setLastName(fName);
			}

		}
	}
	
	public void updateNumber(String id, String pNum) {
		for (Contact contact : contacts) {
			if (contact.getID() == id) {
				contact.setPhoneNumber(pNum);
			}
		}
	}
	
	public void updateAddress(String id, String addrss) {
		for (Contact contact : contacts) {
			if (contact.getID() == id) {
				contact.setAddress(addrss);
			}
		}
	}
	
	
}
