import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	@Test
	void WansntAbleToAddAppointmentWithUniqueID() {
		AppointmentService aService = new AppointmentService();
		Appointment appointment = new Appointment("id", new Date(3000+1900,01,01), "desc");
		System.out.println("fdfsaffsa");
		aService.addAppointment(appointment.getID(), appointment.getDate(), appointment.getDescription());
		if(!(aService.getAppointment("id").getID() == appointment.getID()) &&
				!(aService.getAppointment("id").getDate() == appointment.getDate()) &&
				!(aService.getAppointment("id").getDescription() == appointment.getDescription()) ) {
			fail();
		}
	}
	
	@Test
	void WasAbleToAddAppointmentWithSameID() {
		AppointmentService aService = new AppointmentService();
		aService.addAppointment("1",new Date(),"notNull");
		assertThrows(IllegalArgumentException.class, () -> {
			aService.addAppointment("1",new Date(),"fdfsfa");
		});
	}
	
	@Test
	void WasntAbleToDeleteAppointmentPerID() {
		AppointmentService aService = new AppointmentService();
		aService.addAppointment("1",new Date(),"notNull");
		aService.addAppointment("2",new Date(),"fdfsfa");
		aService.addAppointment("3",new Date(),"notNull");
		aService.deleteAppointment("2");
		if(aService.getAppointment("2") != null) {
			fail();
		}
	}




}
